//: Playground - noun: a place where people can play

import UIKit

class Person {
    var name: String
    var age: Int
    var money: Int = 0
    init(name: String, age: Int){
        self.name = name
        self.age = age
    }
}

protocol LenderBehavior: class {
    func lendMoney(borrower: BorrowerBehavior, money: Int) -> Bool
    func requestPayment()
    
}
protocol BorrowerBehavior {
    func askForMoney(lender: LenderBehavior, money: Int)
    func recieveMoney(lender: LenderBehavior, money: Int)
    func payMoneyBack() -> Int?
}

class Lender: Person, LenderBehavior {
    var borrower: BorrowerBehavior?
    func lendMoney(borrower: BorrowerBehavior, money: Int) -> Bool {
        guard self.money >= money else { return false }
        self.borrower = borrower
        self.money -= money
        borrower.recieveMoney(lender: self, money: money)
        return true
    }
    func requestPayment() {
        if let borrower = self.borrower {
            if let returnMoney = borrower.payMoneyBack() {
                self.money += returnMoney
                self.borrower = nil
                print("Doi no thanh cong")
            }else {
                print("Borrower chua co tien")
            }
        } else {
            print("Co ai muon tien dau ma doi ?")
        }
    }
}
class Borrower: Person, BorrowerBehavior {
    weak var lender: LenderBehavior?
    var debt: Int = 0
    func recieveMoney(lender: LenderBehavior, money: Int) {
        self.lender = lender
        debt = money
        self.money += money
    }
    func payMoneyBack() -> Int? {
        var returnMoney: Int?
        if money >= debt {
            money -= debt
            returnMoney = debt
            debt = 0
            self.lender = nil
        } else {
            return nil
        }
        return returnMoney
    }
    func askForMoney(lender: LenderBehavior, money: Int) {
        if lender.lendMoney(borrower: self, money: money) {
            print("Yeah !!")
        } else {
            print("So sad")
        }
    }
}
let lenderObj = Lender(name: "Le Duc Tanh", age: 22)
lenderObj.requestPayment()
lenderObj.money = 100000
let borrowerObj = Borrower(name: "Le Duc Ngo", age: 26)

borrowerObj.askForMoney(lender: lenderObj, money: 50000)

borrowerObj.debt


