//: Playground - noun: a place where people can play

import UIKit

class Node<Template: Comparable>: Comparable {

    var data: Template!
    var next: Node?
    static func < <Template:Comparable> (lhs: Node<Template>, rhs: Node<Template>) -> Bool {
        return lhs.data < rhs.data
    }
    static func == <Template:Comparable> (lhs: Node<Template>, rhs: Node<Template>) -> Bool {
        return lhs.data == rhs.data
    }
    deinit {
        
        Swift.print("Deleted \(self.data)")
    }
}



class Linklist<Template: Comparable>
{
    var headNode = Node<Template>()
   
   
    public func addHead(element: Template){
       let newNode = Node<Template>()
       
       newNode.data = element
       newNode.next = self.headNode
       self.headNode = newNode
        
    }
    public func addTail(element: Template) {
        if let _ = headNode.data {
            var currentNode = headNode
            while let _ = currentNode.next?.data {
                currentNode = currentNode.next!
            }
            let newNode = Node<Template>()
            newNode.data = element
            newNode.next = currentNode.next
            currentNode.next = newNode
        } else {
            addHead(element: element)
        }
       
    }
    
    public func lprint(){
        if let _ = headNode.data {
            var currentNode = self.headNode
            while let data = currentNode.data {
                Swift.print("-*[\(data)]*-")
                currentNode = currentNode.next!
            }
        } else {
            Swift.print("Linklist is empty")
        }
        
    }
    public func count() -> Int {
        var count: Int = 0
        var currentNode: Node<Template> = self.headNode
        while let _ = currentNode.data {
            count += 1
            currentNode = currentNode.next!
        }
        return count
    }
    
    public func insert(element: Template,at index: Int) {
        if index < 1 {
            Swift.print("The inserted position is invalid")
        } else if index == 1 {
            self.addHead(element: element)
        } else {
            var position: Int = 1
            var currentNode: Node<Template> = self.headNode
            while let _ = currentNode.data , position < (index-1) {
                position += 1
                currentNode = currentNode.next!
            }
            if let _ = currentNode.data {
                
                let newNode: Node<Template> = Node<Template>()
                newNode.data = element
                newNode.next = currentNode.next
                currentNode.next = newNode
            }
            else {
                Swift.print("The inserted position is invalid")
            }
        }
    }
    public func print(at index: Int) {
        if index < 1 {
            Swift.print("The position is invalid")
        }
        else {
            var position: Int = 1
            var currentNode = self.headNode
            while let _ = currentNode.data, position < index {
                position += 1
                currentNode = currentNode.next!
            }
            if let _ = currentNode.data {
                Swift.print("Data of Node at index \(index) is: \(currentNode.data!)")
            }
            else {
                Swift.print("The position is invalid")
            }

        }
    }
    public func delete(at index: Int) {
        if index < 1 {
            Swift.print("The position is invalid")
        }
        else if index == 1 {
            let temp = self.headNode
            headNode = headNode.next!
            temp.next = nil
        }
        else {
            var position: Int = 1
            var currentNode = self.headNode
            while let _ = currentNode.data, position < index-1 {
                position += 1
                currentNode = currentNode.next!
            }
            if let _ = currentNode.data {
                //delete Node after currentNode
                let q = currentNode.next!
                currentNode.next = q.next
                q.next = nil
            }
            else {
                Swift.print("The position is invalid")
            }
        }
    }
    public func sortLinkList() {
        var currentNode = self.headNode
        while let _ = currentNode.next?.data {
            var node = currentNode.next!
            while let _ = node.data {
                
                if node < currentNode {
                    
                    let temp = currentNode.data
                    currentNode.data = node.data
                    node.data = temp
                }
                node = node.next!
            }
            currentNode = currentNode.next!
        }
    }
    public func insertAsc(element: Template){
        let t = Node<Template>()
        var p = Node<Template>()
        var q = Node<Template>()
        t.data = element
        if let _ = headNode.data, headNode.data < element {
            p = headNode
            q = p.next!
            while let _ = q.data, q < t {
                p = q
                q = q.next!
            }
            t.data = element
            t.next = q
            p.next = t

        } else {
            t.next = headNode
            headNode = t
        }
    }
    
}
// Test
var myInts = Linklist<Int>()
myInts.addHead(element: 4)
myInts.addHead(element: 8)
myInts.addHead(element: 10)
myInts.addHead(element: 11)
myInts.addHead(element: 14)
myInts.addHead(element: 23)


var myAnotherInts = Linklist<Int>()
myAnotherInts.addTail(element: 26)
myAnotherInts.addTail(element: 8)
myAnotherInts.addTail(element: 10)
myAnotherInts.addTail(element: 7)
myAnotherInts.addTail(element: 14)
myAnotherInts.addTail(element: 2)


myAnotherInts.count()
myAnotherInts.insert(element: 5, at: 2)

myAnotherInts.print(at: 4)
myAnotherInts.sortLinkList()
myAnotherInts.insertAsc(element: 6)
myAnotherInts.lprint()

class Date : CustomStringConvertible{
    var day: Int
    var month: Int
    var year: Int
    init(day: Int, month: Int, year: Int){
        self.day = day
        self.month = month
        self.year = year
    }
    public var description: String { // toString()
        return String("\(day)/\(month)/\(year)")
    }
    
}

extension Date: Comparable {
    static func ==(lhs: Date, rhs: Date) -> Bool {
        if lhs.day == rhs.day, lhs.month == rhs.month, lhs.year == rhs.year {
            return true
        }
        else {
            return false
        }
    }
    static func < (lhs: Date, rhs: Date) -> Bool {
        if lhs.year < rhs.year {
            return true
        } else if lhs.year == rhs.year {
            if lhs.month < rhs.month {
                return true
            } else if lhs.month == rhs.month {
                if lhs.day < rhs.day {
                    return true
                }
            }
        }
        return false
    }
}

var myDates = Linklist<Date>()
var date1 = Date(day: 23, month: 8, year: 1998)
var date2 = Date(day: 27, month: 6, year: 1999)
var date3 = Date(day: 25, month: 1, year: 1997)
var date4 = Date(day: 29, month: 10, year: 1994)
var date5 = Date(day: 9, month: 10, year: 1991)
var date6 = Date(day: 9, month: 10, year: 1992)
myDates.addTail(element: date1)
myDates.addTail(element: date2)
myDates.addTail(element: date3)
myDates.addTail(element: date4)


myDates.insert(element: date5, at: 3)
myDates.sortLinkList()
myDates.insertAsc(element: date6)

myDates.lprint()




